#include <iostream>
using namespace std;

class Node
{
public:
    int value;
    Node* next;

    Node(int value)
    {
        this->value = value;
        next = nullptr;
    }
}; // Missing semicolon after the class declaration

class LinkedList
{
public:
    Node* head;
    Node* tail;
    int length;

    LinkedList(int value)    // Constructor must be public
    {
        Node* newNode = new Node(value);
        head = newNode;
        tail = newNode;
        length = 1;
    }

    void printList()    // Method must be public
    {
        Node* temp = head;
        while (temp != nullptr)
        {
            cout << temp->value << endl;
            temp = temp->next;
        }
    }
    void getHead()
    {
        cout << "Head: "<< head->value <<endl;
    }
    void getTail()
    {
        cout << "Tail: "<<tail->value <<endl;
    }
    void getLength()
    {
        cout << "Length: "<<length <<endl;
    }
    void append(int value)
    {
        Node* newNode = new Node(value);
        if(length == 0)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail -> next = newNode;
            tail = newNode;
        }
        length++;
    }

    void prepend(int value)
    {
        Node* newNode = new Node(value);
        if(length == 0)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            newNode -> next = head;
            head = newNode;
        }
        length++;
    }
    void deleteLast()
    {
        Node* temp=head;
        if(length == 0) return;
        if(length == 1)
        {
            head = nullptr;
            tail = nullptr;
        }
        else
        {
            Node *prev = head;
            while(temp->next)
            {
                prev = temp;
                temp = temp->next;
            }

            tail = prev;
            tail -> next = nullptr;
        }
        delete temp;
        length --;

    }
    void deleteFirst()
    {
        Node* temp = head;
        if(length == 0) return;
        if(length == 1)
        {
            head = nullptr;
            tail = nullptr;
        }
        else
        {
            head = head -> next;
        }
        delete temp;
        length --;
    }

    Node* get(int index)
    {
        if(index < 0 || index >=length)
        {
            return nullptr;
        }
        Node* temp = head;
        for(int i=0; i<index; i++)
        {
            temp = temp->next;
        }
        return temp;
    }
    bool set(int value, int index)
    {
        Node *temp = get(index);
        if(temp)
        {
            temp->value = value;
            return true;
        }
        return false;

    }
    bool insert(int index, int value)
    {
        if(index < 0 || index > length) return false;
        if(index == 0)
        {
            prepend(value);
            return true;
        }
        if(index == length )
        {
            append(value);
            return true;
        }
        Node* newNode = new Node(value);
        Node* temp = get(index-1);
        newNode->next = temp->next;
        temp->next = newNode;
        length++;
        return true;
    }
    void deleteNode(int index)
    {
        if(index < 0 || index >=length) return;
        if(index == 0) return deleteFirst();
        if(index == length-1) return deleteLast();

        Node* prev = get(index-1);
        Node* temp = prev->next;

        prev->next = temp->next;
        delete temp;
        length--;
    }

    Node* findMiddleNode()
    {
        Node*fast = head;
        Node*slow = head;
        while(fast != nullptr && fast->next != nullptr)
        {
            fast = fast->next->next;
            slow = slow->next;
        }
        return slow;
    }
    void reverse()
    {
        Node *temp = head;
        head = tail;
        tail = temp;

        Node* after = temp -> next;
        Node* before = nullptr;

        for(int i=0; i<length; i++)
        {
            after = temp->next;
            temp->next = before;
            before = temp;
            temp = after;
        }
    }
    void reverseLinkedList(Node* node)
    {
        if (node == nullptr) return;  // Base case: if the node is null, return
        reverseLinkedList(node->next);  // Recursive call with the next node
        cout << node->value << endl;  // Print the value after the recursive call, creating a reverse print order
    }

// Helper function to call reverseLinkedList from the head
    void reverseLinkedList()
    {
        reverseLinkedList(head);
    }

}; // Missing semicolon after the class declaration

int main()
{
    LinkedList* myLinkedList = new LinkedList(2);
    myLinkedList->append(4);
    myLinkedList->append(6);
    myLinkedList->append(10);
    myLinkedList->append(12);
    myLinkedList->append(14);

    // cout << "Middle Node is: "<< myLinkedList->findMiddleNode()->next<<endl;

    myLinkedList->reverseLinkedList();



    return 0;
}
