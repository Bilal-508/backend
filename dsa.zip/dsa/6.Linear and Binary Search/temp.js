let arr = [2, 4, 6, 8, 10, 12, 16, 18, 20];

function linearSearch(arr, key) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === key) {
      return i;
    }
  }
  return -1;
}

function BinarySearch(arr, key) {
  let high, low, mid;
  high = arr.length - 1;
  low = 0;

  while (low <= high) {
    mid = Math.floor((low + high) / 2);
    if (arr[mid] === key) {
      return mid;
    } else if (key < arr[mid]) {
      high = mid - 1;
    } else if (key > arr[mid]) {
      low = mid + 1;
    }
  }
  return -1;
}

let result = BinarySearch(arr, 16);
if (result === -1) {
  console.log("Element not found");
} else {
  console.log("Element found at index: ", result);
}
