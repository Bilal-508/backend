#include<iostream>
using namespace std;

class Node{
    public:
        int value;
        Node* next;
    
    Node(int value){
        this->value = value;
        next = nullptr;
    }
};

class Stack{
    private:
        Node* top;
        int height;
    public:
        Stack(int value){
            Node* newNode = new Node(value);
            top = newNode;
            height = 1;
        }
        
        void printStack(){
            Node* temp = top;
            while(temp != nullptr){
                cout<<temp->value<<endl;
                temp = temp->next;
            }
        }
        
        void getTop(){
            cout<<"Top Height: "<<top->value<<endl;
        }
        
        void getHeight(){
            cout <<"Height: "<< height <<endl;
        }
        void push(int value){
            Node* newNode = new Node(value);
            newNode->next = top;
            top = newNode;
            height++;
        }
        int pop(){
            if(height == 0) return 0;
            Node* temp = top;
            int poppedValue = top->value;
            top = top->next;
            delete temp;
            height --;
            
            return poppedValue;
        }
    
};
int main(){
    Stack *s= new Stack(6);
    cout << "Popped Value: "<<s->pop()<<endl;
    cout << "Popped Value: "<<s->pop()<<endl;
    // s->printStack();
    // s->getTop();
    // s->getHeight();
    
}