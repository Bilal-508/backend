const MAX_SIZE = 5;
let stack = new Array(MAX_SIZE);  
let top = -1;  

function push(x) {
    if (top === MAX_SIZE - 1) {
        console.log("Stack Overflow");
        return;
    }
    top++;
    stack[top] = x;
    
    //stack[++top] = x;
}

function pop() {
    if (top === -1) {
        console.log("No Elements in the Stack");
        return;
    }
    top--;  
}

function print() {
    console.log("Stack:");
    for (let i = 0; i <= top; i++) {
            console.log(stack[i]);
    }
}

push(1);
push(2);
push(3);
print();  

pop();
print();  
