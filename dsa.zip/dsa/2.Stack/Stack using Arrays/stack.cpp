#include <iostream>
using namespace std;

#define MAX_SIZE 101
int a[MAX_SIZE];
int top = -1;

void push(int x){
    if(top == MAX_SIZE == -1){
        cout << "Stack Overflow"<<endl;
        return;
    }
    top++;
    a[top] = x;
    //a[++top] = x
}
void pop(){
    if(top == -1){
        cout<<"No Elements in the Stack"<<endl;
        return;
    }
    top--;
}
void print(){
    cout<<"Stack"<<endl;
    for(int i=0; i<=top; i++){
        cout << a[i] << ",";
    }
    cout << endl;
}
int getTop(){
    return a[top];
}
int main(){
    push(2);
    push(9);
    push(8);
    cout << getTop() << endl;
    print();
    cout << "After Pop: "<<endl;
    pop();
    print();
}
