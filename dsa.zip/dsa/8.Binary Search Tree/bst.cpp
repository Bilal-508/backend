#include <iostream>
#include <queue>
using namespace std;

class Node{
    public:
        int value;
        Node *left;
        Node *right;

    Node(int value){
        this->value = value;
        left = nullptr;
        right = nullptr;
    }
};

class BinarySearchTree{
    public:
        Node *root;
    public:
        BinarySearchTree(){
            root = nullptr;
        }
        bool insert(int value){
            Node *newNode = new Node(value);
            Node *temp = root;
            if(root == nullptr){
                root = newNode;
                return true;
            }
            while(true){
                if(newNode -> value == temp->value) return false;
                if(newNode -> value < temp-> value){
                    if(temp->left == nullptr){
                        temp->left = newNode;
                        return true;
                    }
                    temp = temp->left;
                }
                else {
                        if(temp-> right == nullptr){
                            temp->right = newNode;
                            return true;
                        }
                        temp = temp -> right;
                    }
            }
        }
        bool contains(int value){
            Node* temp = root;
            while(temp){
                if(value < temp->value){
                    temp = temp->left;
                }
                else if(value > temp->value){
                    temp = temp->right;
                }
                else return true;
            }
            return false;
        }

        void findMin(){
            Node* temp = root;
            if(root == nullptr){
                cout << "Error" << endl;
                return;
            }
            while (temp->left != nullptr){
                temp = temp -> left;
            }
            cout << "Min Value: "<< temp->value <<endl;
        }

        void findMax(){
            Node* temp = root;
            if(root == nullptr){
                cout << "Error" << endl;
                return;
            }
            while(temp->right != nullptr){
                temp = temp->right;
            }
            cout << "Max value: "<<temp->value<<endl;
        }

        void BFS(){
            queue<Node*>myQueue;
            myQueue.push(root);

            while(myQueue.size() > 0){
                Node*currentNode = myQueue.front();
                myQueue.pop();
                cout << currentNode -> value << endl;
                if(currentNode -> left != nullptr){
                    myQueue.push(currentNode -> left);
                }
                if(currentNode -> right != nullptr){
                    myQueue.push(currentNode -> right);
                }
            }
        }

};
int main(){
    BinarySearchTree* myBST = new BinarySearchTree();
    myBST -> insert(47);
    myBST -> insert(21);
    myBST -> insert(76);
    myBST -> insert(18);
    myBST -> insert(27);
    myBST -> insert(52);
    myBST -> insert(82);

    myBST-> BFS();

    // myBST ->findMax();
}



