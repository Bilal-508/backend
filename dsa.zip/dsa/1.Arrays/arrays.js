function insertAtSpecificPosition(arr, index, element) {
  if (index < 0 || index >= arr.length) {
    console.log("Invalid Index");
    return;
  }
  for (let i = arr.length - 1; i >= index; i--) {
    arr[i + 1] = arr[i];
  }
  arr[index] = element;
  return arr;
}

function insertAtStart(arr, element) {
  for (let i = arr.length - 1; i >= 0; i--) {
    arr[i + 1] = arr[i];
  }
  arr[0] = element;
  return arr;
}

function insertAtEnd(arr, element) {
  arr[arr.length] = element;
  return arr;
}
function deleteAtSpecificPosition(arr, index) {
  let item;
  if (index < 0 || index >= arr.length || arr.length === 0) return 0;
  else {
    item = arr[index];
    for (let i = index; i < arr.length - 1; i++) {
      arr[i] = arr[i + 1];
    }
    arr.length--;
    return item;
  }
}

function deleteAtEnd(arr) {
  return arr.length--;
}
function deleteAtStart(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = arr[i + 1];
  }
  arr.length--;
  return arr;
}

let numbers = [1, 2, 3, 4, 5];
deleteAtStart(numbers);
console.log(numbers);

/*
if index is 0 we have to shift all the elements this means n shift
if index is 1 n-1 shift requires
if index is 2 n-2 shift requires
Time complexity is O(n-index)

optimal solution for unsorted array Insertion
arr[arr.length] = arr[index];
arr[index] = element
*/

/*
Optimal Solution for unsorted Array Deletion
arr[arr.length] = arr[index];
arr.length --

*/
