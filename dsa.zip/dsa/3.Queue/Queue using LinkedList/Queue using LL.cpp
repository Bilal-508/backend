#include<iostream>
using namespace std;

class Node{
    public:
        Node* next;
        int value;
    Node(int value){
        this->value = value;
        next = nullptr;
    }
};

class Queue{
    private:
        Node *front;
        Node *rear;
        int length;
    
    public:
        Queue(int value){
            Node* newNode = new Node(value);
            front = newNode;
            rear = newNode;
            length = 1;
        }
        
        void printQueue(){
            Node* temp = front;
            while(temp != nullptr){
                cout << temp->value<<endl;
                temp = temp->next;
            }
        }
        void getFront(){
            cout << "Front: "<<front->value<<endl;
        }
        void getRear(){
            cout << "Rear: "<<rear->value <<endl;
        }
        void getLength(){
            cout << "Length: "<<length<<endl;
        }
        void enQueue(int value){
            Node* newNode = new Node(value);
            if(length == 0){
                front = newNode;
                rear = newNode;
            }
            else{
                rear -> next = newNode;
                rear = newNode;
            }
            length++;
        }
        int deQueue(){
            Node* temp = front;
            if(length == 0) return -1;
            int dequeuedValue = front -> value;
            if(length == 1){
                front = nullptr;
                rear = nullptr;
            }
            else {
                front = front->next;
            }
            delete temp;
            length --;
            return dequeuedValue;
            
        }
        
        
};

int main(){
    Queue *q = new Queue(8);
    q->enQueue(10);
    q->enQueue(20);
    q->enQueue(30);
    q->enQueue(40);
    q->printQueue();
    q->getFront();
    q->getRear();
    q->getLength();
    
    cout << "Dequeue Value: "<<q->deQueue()<<endl;
    cout << "Dequeue Value: "<<q->deQueue()<<endl;
    
    cout << "--------------After Dequeue---------------------"<<endl;
    q->printQueue();
    q->getFront();
    q->getRear();
    q->getLength();
    return 0;
}