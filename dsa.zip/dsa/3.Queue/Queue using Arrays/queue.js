const MAX_SIZE = 5;
let queue = new Array(MAX_SIZE);
let front = -1;
let rear = -1;

function EnQueue(x) {
  if (isFull()) {
    console.log("Queue is full");
    return;
  } else if (isEmpty()) {
    front = 0;
    rear = 0;
  } else {
    rear++;
  }
  queue[rear] = x;
}

function Dequeue() {
  console.log("dequeue called");

  if (isEmpty()) {
    console.log("Queue is empty");
    return;
  }
  if (front === rear) {
    front = -1;
    rear = -1;
  } else {
    front++;
  }
}

function isEmpty() {
  if (front === -1 && rear === -1) {
    return true;
  } else {
    return false;
  }
}

function isFull() {
  if (rear === MAX_SIZE - 1) {
    return true;
  } else {
    return false;
  }
}

// EnQueue(8);
// EnQueue(80);
// EnQueue(180);
// EnQueue(280);
// EnQueue(380);
// EnQueue(480);

Dequeue();

EnQueue(8);
EnQueue(80);
EnQueue(180);

Dequeue();

console.log(queue);
