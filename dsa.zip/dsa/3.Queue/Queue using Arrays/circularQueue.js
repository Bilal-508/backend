const MAX_SIZE = 5;
let queue = new Array(MAX_SIZE);
let front = -1;
let rear = -1;

function EnQueue(x) {
  if (isFull()) {
    console.log("Queue is full");
    return;
  } else if (isEmpty()) {
    front = 0;
    rear = 0;
  } else {
    rear = (rear + 1) % MAX_SIZE;
  }
  queue[rear] = x;
}

function Dequeue() {
  if (isEmpty()) {
    console.log("Queue is empty");
    return;
  }
  if (front === rear) {
    front = -1;
    rear = -1;
  } else {
    front = (front + 1) % MAX_SIZE;
  }
  queue[front] = null;
}

function isEmpty() {
  if (front === -1 && rear === -1) {
    return true;
  } else {
    return false;
  }
}

function isFull() {
  if ((rear + 1) % MAX_SIZE === front) {
    return true;
  } else {
    return false;
  }
}
// Test the circular queue
EnQueue(10);
EnQueue(20);
EnQueue(30);
EnQueue(40);
EnQueue(50);
// EnQueue(60); // Should print "Queue is full" because the queue has MAX_SIZE elements

Dequeue();
Dequeue();

// EnQueue(1);
// EnQueue(2);

console.log(queue);

/*
For circular Queue
currentPosition = i;
nextPosition = (i+1) % n;

if(i>0) previousPosition=(i−1) % n
if(i===0) previousPosition=(i+n−1) mod n

*/
